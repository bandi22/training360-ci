package employees.service;

import lombok.Data;

@Data
public class UpdateEmployeeCommand {

    private String name;
}
